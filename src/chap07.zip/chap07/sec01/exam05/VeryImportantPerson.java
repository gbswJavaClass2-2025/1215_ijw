package chap07.sec01.exam05;

//public class VeryImportantPerson extends Member{
//}

// 위 코드 작동 X
package chap07.sec01.exam07.pack1;

public class A {
    protected String field; // 같은 패키지 안에선 자유, 하지만 외부 패키지에선 자식 클래스만 접근 가능

    protected A() {

    }

    protected void method() {

    }
}

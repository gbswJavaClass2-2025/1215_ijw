package chap07.sec01.exam06;

public class SportsCar extends Car{
    @Override
    public void speedUp() {speed += 10;}

    // final 접근 제한자 때문에 안되죠...
//    @Override
//    public void stop() {
//        System.out.println("스포츠카를 멈춤");
//        speed = 0;
//    }
}

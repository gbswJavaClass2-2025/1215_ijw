package chap07.sec02.exam06;

public class Child extends Parent {
}

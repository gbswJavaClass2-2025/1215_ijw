package chap07.sec01.exam05;
// final은 자식이 없음... ~~무정자증~~???
public final class Member {
    
}

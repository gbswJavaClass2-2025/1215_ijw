package test.one;

public class BasicControl {
    static void main() {
        for (int i = 1; i <= 9; i++) System.out.printf("%d X %d = %d\n", 2, i, 2*i);
    }
}
